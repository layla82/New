from flask import Flask, jsonify,request
import urlfiltering

app = Flask(__name__)

pp = Flask(__name__)




@app.route('/url',methods=['POST'])
def index():
    #print request.json['name'];
    json_data = request.get_json(force=True)
    json_data2 = request.get_json()
    print (json_data2['name']) 
    blacklist_url=json_data2['name']
    value=blacklisting(blacklist_url)
    

    return value


def blacklisting(geturl):
    input=geturl
    #returns line of the target, or None if doesnt exist
    
    with open('Urllist.txt') as myfile:
     if input in myfile.read():
         return "already added"
     else:
            result=updatelist(input)
            finalresult= result
            return finalresult
            

    

def updatelist(url):
    
    state= urlfiltering.urlfilteringresult(url)
    print(state)
    if state==1:
        file=open('Urllist.txt','a')
        file.write(url)
        return "added and blocked"
        
    else:
        return "not added its safe"


if __name__ == '__main__':
    app.run()
