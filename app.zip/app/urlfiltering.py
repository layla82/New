import trainer as tr
import pandas
import main



def urlfilteringresult(eurl):
	url=eurl
	main.process_test_url(url,'test_features.csv')
	return_ans = tr.gui_caller('url_features.csv','test_features.csv')
	a=str(return_ans).split()
	if int(a[1])==0:
		return 0
	elif int(a[1])==1:
		return 0
	else:
		return 1
