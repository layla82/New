
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("submit").addEventListener("click", myFunction);
});



function myFunction() {
var name = document.getElementById("user").value;
var password = document.getElementById("pass").value;
// Returns successful data submission message when the entered information is stored in database.
var dataString = 'name1=' + name + '&password1=' + password;
if (name == '' || password == '' ) {
alert("Please Fill All Fields");
} else {
// AJAX code to submit form.
$.ajax({
type: "POST",
url: "user.php",
data: dataString,
cache: false,
success: function(html) {
// do nothing
}
});
}
return false;
}